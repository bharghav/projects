<div class="site_rgt">
           		<div class="admin_blg">
                	<div class="admin_blg_in">
                    	<div class="admin_blg_in_lft">
                        	<a href="#"><img src="images/admin_pic_03.png" alt=""></a>
                        </div><!--admin_blg_in_lft-->
                        <div class="admin_blg_in_rgt">
                        	<span>Admin</span>
                            <span><img src="images/admin_pic_06.png" alt=""></span>
                        </div><!--admin_blg_in_rgt-->	
                    </div><!--admin_blg_in-->
                </div><!--admin_blg-->
                <div class="content_blg">
                	<div class="page_name_blg">
                    	<div class="page_name_lft">
                    		<h2>Dashbord</h2>
                        </div><!--page_name_lft-->
                        <div class="page_name_rgt">
                        	<a href="#"><img src="images/settng_pic_14.png" alt=""></a>
                        </div><!--page_name_rgt-->
                    </div><!--page_name_blg-->
                    <div class="title_blg">
                    	<ul>
                        	<li><a href="#"><img src="images/title_pics_19.png" alt=""></a></li>
                            <li><a href="#">Home</a></li>
                            <li><a href="#"><img src="images/title_pics_22.png" alt=""></a></li>
                            <li><a href="#">Dashboard</a></li>
                        </ul>
                    </div><!--title_blg-->
                    <div class="more_info_blg">
                    	<div class="more_info_blg_in">
                        	<img src="images/mr_pics_31.png" alt="">
                            <div class="more_pos">
                            	<h3>Configuration <br> Settings </h3>
                                <p><a href="#">more info</a> <img src="images/more_pic_06.png" alt=""></p>
                            </div><!--more_pos-->	
                        </div><!--more_info_blg_in-->
                        
                    	<div class="more_info_blg_in">
                        	<img src="images/mr_pics_33.png" alt="">
                            <div class="more_pos">
                            	<h3>Content <br> Pages </h3>
                                <p><a href="#">more info</a> <img src="images/more_pic_06.png" alt=""></p>
                            </div><!--more_pos-->	
                        </div><!--more_info_blg_in-->
                        
                        <div class="more_info_blg_in">
                        	<img src="images/mr_pics_35.png" alt="">
                            <div class="more_pos">
                            	<h3>Customers <br> Management </h3>
                                <p><a href="#">more info</a> <img src="images/more_pic_06.png" alt=""></p>
                            </div><!--more_pos-->	
                        </div><!--more_info_blg_in-->
                        
                        <div class="more_info_blg_in">
                        	<img src="images/mr_pics_37.png" alt="">
                            <div class="more_pos">
                            	<h3>Order <br> Management </h3>
                                <p><a href="#">more info</a> <img src="images/more_pic_06.png" alt=""></p>
                            </div><!--more_pos-->	
                        </div><!--more_info_blg_in-->      
                        
                    </div><!--more_info_blg-->
                    <div class="count_blg">
                    	<div class="count_blg_lft">
                        	<div class="count_blg_lft_top">
                            	<ul>
                                	<li>
                                    	<p>Total Order Count</p>
                                        <p><a href="#">View All</a></p>
                                        <span>48</span>
                                    </li>
                                    <li>
                                    	<p>Total Order Count</p>
                                        <p><a href="#">View All</a></p>
                                        <span>12</span>
                                    </li>
                                    <li>
                                    	<p>Total Order Count</p>
                                        <p><a href="#">View All</a></p>
                                        <span>36</span>
                                    </li>
                                    <li>
                                    	<p>Total Order Count</p>
                                        <p><a href="#">View All</a></p>
                                        <span>52</span>
                                    </li><li>
                                    	<p>Total Order Count</p>
                                        <p><a href="#">View All</a></p>
                                        <span>10</span>
                                    </li>
                                    <li>
                                    	<p>Total Order Count</p>
                                        <p><a href="#">View All</a></p>
                                        <span>64</span>
                                    </li>
                                </ul>
                            </div><!--count_blg_lft_top-->
                            <div class="count_blg_lft_mid">
                            	<div class="count_blg_lft_mid_in">
                                	<p>Total Sale</p>
                                    <h1>6,24,421,100</h1>
                                    <span><a href="#">View All</a></span>
                                </div><!--count_blg_lft_mid_in-->
                                
                                <div class="count_blg_lft_mid_in new_bg">
                                	<p>New Customers</p>
                                    <h1>120 <small>members</small></h1>
                                    <span><a href="#">View All</a></span>
                                </div><!--count_blg_lft_mid_in-->
                                
                            </div><!--count_blg_lft_mid-->
                            
                            <div class="count_blg_lft_btm">
                            	<div class="count_blg_lft_btm_in">
                                	<div class="count_blg_lft_btm_in_lft">
                                    	<img src="images/pi_pic_03.png" alt="">
                                    </div><!--count_blg_lft_btm_in_lft-->
                                    <div class="count_blg_lft_btm_in_rgt">
                                    	<div class="count_blg_lft_btm_in_rgt_top">
                                        	<img src="images/pi2_pics_03.png" alt="">
                                            <span>New Customers</span>
                                        </div><!--count_blg_lft_btm_in_rgt_top-->
                                        <div class="count_blg_lft_btm_in_rgt_top">
                                        	<img src="images/pi2_pics_10.png" alt="">
                                            <span>Returning Customers</span>
                                        </div><!--count_blg_lft_btm_in_rgt_top-->
                                    </div><!--count_blg_lft_btm_in_rgt-->
                                </div><!--count_blg_lft_btm_in-->
                                
                                <div class="active_users">
                                	<div class="active_users_lft">
                                    	<div class="num_blg">
                                        	<h1>35</h1>
                                        </div><!--num_blg-->
                                        <p>Active users on site 
right now...</p>
                                    </div><!--active_users_lft-->
                                    <div class="active_users_rgt">
                                    	<a href="#"><img src="images/man_pic_03.png" alt=""></a>
                                    </div><!--active_users_rgt-->
                                </div><!--active_users-->
                            </div><!--count_blg_lft_btm-->
                        </div><!--count_blg_lft-->
                        
                        <div class="count_blg_rgt">
                        	<div class="latest_blog">
                            	<div class="latest_blog_top">
                                	<div class="latest_blog_top-lft">
                                    	<span>Latest Orders</span>
                                    </div><!--latest_blog_top-lft-->
                                    <div class="latest_blog_top-rgt">
                                    	<input type="submit" value="">
                                    </div><!--latest_blog_top-rgt-->
                                </div><!--latest_blog_top-->
                                
                                <div class="latest_blog_mid">
                                	<div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                </div><!--latest_blog_mid-->
                            </div><!--latest_blog-->
                            
                            <div class="latest_blog ovr_non">
                            	<div class="latest_blog_top">
                                	<div class="latest_blog_top-lft">
                                    	<span>Most Viewed Products</span>
                                    </div><!--latest_blog_top-lft-->
                                    
                                </div><!--latest_blog_top-->
                                
                                <div class="latest_blog_mid ovr_non">
                                	<div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->
                                    
                                    <div class="name_of_pil">
                                    	<span><img src="images/bell_pics_07.png" alt=""></span>
                                        <small>Name of the Pill  - Id: #404-5082292-3658754   - </small>
                                        <small style="color:#fd781f;"> $74.99</small>
                                        <i>Just Now</i>
                                    </div><!--name_of_pil-->                          
                                    
                                </div><!--latest_blog_mid-->
                            </div><!--latest_blog-->
                            
                        </div><!--count_blg_rgt-->
                    </div><!--count_blg-->
                </div><!--content_blg--> 
           </div><!--site_rgt-->
    </div><!--site_wrap-->
    
    <div class="foot_wrap">
    	<span>2015 © cheapsleepingpills. Admin Dashboard Template. </span>
    </div><!--foot_wrap-->
</body>
</html>
