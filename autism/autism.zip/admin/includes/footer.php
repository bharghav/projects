<div class="foot_wrap">

    	<span>2015 &copy; Pratyusha. </span>

    </div><!--foot_wrap-->



</body>

</html>

