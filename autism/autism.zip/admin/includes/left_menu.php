<nav id="main_menu">
                <div class="menu_wrapper">
                    <ul>
                        <li class="first_level">
                            <a href="index.php?option=com_dashboard">
                                <span class="icon_house_alt first_level_icon"></span>
                                <span class="menu-title">Dashboard</span>
                            </a>
                        </li>
                        <li class="first_level">
                            <a href="javascript:void(0)">
                                <span class="icon_document_alt first_level_icon"></span>
                                <span class="menu-title">Users</span>
                            </a>
                            <ul>
                                <li class="submenu-title">Forms</li>
                                <li><a href="forms-regular_elements.html">Admin Users</a></li>
                                <li><a href="forms-extended_elements.html">Front  users</a></li>
                            </ul>
                        </li>
                        <li class="first_level">
                            <a href="javascript:void(0)">
                                <span class="icon_folder-alt first_level_icon"></span>
                                <span class="menu-title">Banner</span>
                            </a>
                            <ul>
                                <li class="submenu-title">Left banner </li>
                                <li><a href="pages-chat.html">Right banner </a></li>
                                <li><a href="pages-contact_list.html">Exclusive  banner</a></li>
                                <li><a href="error_404.html">Economic banner</a></li>
                            </ul>
                        </li>
                        <li class="first_level">
                            <a href="javascript:void(0)">
                                <span class="icon_puzzle first_level_icon"></span>
                                <span class="menu-title">Store</span>
                            </a>
                            <ul>
                                <li class="submenu-title">Category</li>
                                <li><a href="components-bootstrap.html">Sub Category</a></li>
                                <li><a href="components-gallery.html">Products</a></li>
                                <li><a href="components-grid.html">Bulk Products</a></li>
                            </ul>
                        </li>
                        
                        
                        
                        
                      
                        
                        
                       
                        <li class="first_level">
                            <a href="javascript:void(0)">
                                <span class="icon_lightbulb_alt first_level_icon"></span>
                                <span class="menu-title">orders</span>
                            </a>
                            <ul>
                                <li class="submenu-title">Orders</li>
                                <li><a href="plugins-ace_editor.html">Orders Management</a></li>
                                <li><a href="plugins-calendar.html">Financial Reports</a></li>
                                <li><a href="plugins-charts.html">Shipping Labels</a></li>
                            </ul>
                        </li>  
                         <li class="first_level">
                            <a href="javascript:void(0)">
                                <span class="icon_lightbulb_alt first_level_icon"></span>
                                <span class="menu-title">Coupoun code</span>
                            </a>
                            <ul>
                                <li class="submenu-title">Orders</li>
                            </ul>
                        </li>
                        
                        
                      <li class="first_level">
                            <a href="javascript:void(0)">
                                <span class="icon_puzzle first_level_icon"></span>
                                <span class="menu-title">Other</span>
                            </a>
                            <ul>
                                <li class="submenu-title">Newsletter Subscribers</li>
                                <li><a href="components-bootstrap.html">Adds banner  </a></li>
                                <li><a href="components-gallery.html">We mant it all</a></li>
                                <li><a href="components-grid.html">Front  middle banner </a></li>
                                <li><a href="components-icons.html">Contact us</a></li>
                             </ul>
                        </li>
                        
                        
                    </ul>
                </div>
                <div class="menu_toggle">
                    <span class="icon_menu_toggle">
                        <i class="arrow_carrot-2left toggle_left"></i>
                        <i class="arrow_carrot-2right toggle_right" style="display:none"></i>
                    </span>
                </div>
            </nav>